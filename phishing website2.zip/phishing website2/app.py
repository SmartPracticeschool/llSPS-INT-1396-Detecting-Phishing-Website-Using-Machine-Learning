import numpy as np
from flask import Flask, request, jsonify, render_template
import pickle
from joblib import load
app = Flask(__name__)
app = Flask(__name__,template_folder='template')
model = pickle.load(open('Detect.pkl', 'rb'))

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/y_predict',methods=['POST'])
def y_predict():
    
    x_test = [[float(x) for x in request.form.values()]]
    print(x_test)
    nb = load('scalar2.save')
    prediction = nb.predict(x_test)
    print(prediction)
    output=prediction[0]
    if output== -1:
        pred = "Does not Detects Phishing Website"
    elif output== 1:
        pred="Detects Phishing Website "
    else :
        pred = "check the value"
        
    return render_template('index.html', prediction_text='{}'.format(pred))

@app.route('/predict_api',methods=['POST'])
def predict_api():
    '''
    For direct API calls trought request
    '''
    data = request.get_json(force=True)
    prediction = model.y_predict([np.array(list(data.values()))])

    output = prediction[0]
    return jsonify(output)

if __name__ == "__main__":
    app.run(debug=True)